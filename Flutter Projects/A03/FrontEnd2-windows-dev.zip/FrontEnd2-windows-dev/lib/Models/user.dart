class UserLogin {
  final String email, password;

  UserLogin(this.email, this.password);
}
