#include <iostream>


int main() {
    //This is merely a test to check for comments single line


        std::cout << "Hello, world!" << std::endl;
        /*
        *This is a muliline comment test, do I work
        */
    return 0;
}