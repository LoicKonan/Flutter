import abc


class Utility(metaclass=abc.ABCMeta):
    ...
